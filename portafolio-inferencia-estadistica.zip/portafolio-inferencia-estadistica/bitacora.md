# 📔 Bitácora de Aprendizaje — Unidad de Inferencia Estadística

**Estudiante:** Lenin Fabricio Macas Cabrera
**Materia:** Teoría de la Distribución y Probabilidad
**Ciclo:** II
**Docente:** Ing. Cristian Narváez

---

## 1. Resumen de la unidad

*(Describe brevemente qué abarcó la unidad de inferencia estadística: estimación puntual, intervalos de confianza, pruebas de hipótesis, etc.)*

---

## 2. Aprendizajes clave

- *(Aprendizaje 1: ej. comprensión de la diferencia entre estimación puntual y por intervalos)*
- *(Aprendizaje 2: ej. aplicación de pruebas de hipótesis a datos reales)*
- *(Aprendizaje 3: ej. interpretación de resultados estadísticos en contexto)*

---

## 3. Dificultades algorítmicas superadas

*(Detalla los obstáculos técnicos o de programación/cálculo que enfrentaste durante las guías APE 06–APE 11 y cómo los resolviste. Por ejemplo: errores en la implementación de fórmulas, manejo de datos, interpretación de resultados de librerías, etc.)*

- **Dificultad:** *(describe el problema)*
  **Solución:** *(cómo lo resolviste)*

- **Dificultad:** *(describe el problema)*
  **Solución:** *(cómo lo resolviste)*

---

## 4. Aplicación en la evaluación sumativa

*(Explica cómo aplicaste lo aprendido al trabajar con los datos de Loja en la evaluación final: qué método usaste, qué resultado obtuviste, qué conclusiones sacaste.)*

---

## 5. Autoevaluación

| Criterio | Valoración (1-5) | Comentario |
|---|---|---|
| Comprensión teórica | | |
| Aplicación práctica | | |
| Resolución de problemas | | |
| Autonomía en el aprendizaje | | |

---

## 6. Conclusión personal

*(Cierra con una reflexión final sobre tu crecimiento en esta unidad y qué aspectos te gustaría reforzar a futuro.)*
